# Cuerda de Tres Lazos - Cuaderno Digital de Pareja

Esta es una app web romántica y espiritual para parejas que quieren mantener su amor con Dios en el centro.

## Para ejecutar localmente

1. Instala Node.js (https://nodejs.org/)
2. Abre terminal en esta carpeta
3. Ejecuta:
   ```
   npm install
   npm start
   ```
4. Abre http://localhost:3000 para ver la app.

## Para desplegar en Vercel

1. Sube este proyecto a un repositorio en GitHub.
2. Ve a https://vercel.com y conecta tu repositorio.
3. Configura el proyecto y despliega.
4. Cambia el dominio a `cuerda-de-tres-lazos` desde el dashboard de Vercel.

---

¡Disfruta tu cuaderno digital con Dios en el centro!